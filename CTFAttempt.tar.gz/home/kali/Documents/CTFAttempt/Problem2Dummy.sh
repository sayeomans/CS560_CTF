#!/bin/bash
#Not this file!
i=1
while :
do
  if [ $i -eq 2 ]; then
    echo
  else
    sleep 1
  fi
done
