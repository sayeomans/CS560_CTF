#!/bin/bash
#This file! *3dT3bA2$
i=1
while :
do
  if [ $i -eq 2 ]; then
    echo
  else
    sleep 1
  fi
done
