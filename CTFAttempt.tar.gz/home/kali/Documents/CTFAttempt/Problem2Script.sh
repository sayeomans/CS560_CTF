#!/bin/bash
#The flag is located in a file called randomFile3.sh
i=1
while :
do
  if [ $i -eq 2 ]; then
    echo
  else
    sleep 1
  fi
done
